# British English VS American English

| Word             | British English    | American English     |
| ---------------- | ------------------ | -------------------- |
| holiday/vacation | You go on holiday. | You take a vacation. |
|                  |                    |                      |
|                  |                    |                      |





