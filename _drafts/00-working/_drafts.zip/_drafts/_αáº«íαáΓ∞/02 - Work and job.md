# Work and Job

> Когда нужно вставить job или work в пробелы нужно обязательно смотреть на артикли. Например, I'm starting a new .. (job) next week. В пробел можно  вставить только job, так как work - uncountable, то есть используется без "a".

![10-job-and-work](C:\STD\sn\Навыки\Английский язык\material\images\10-job-and-work.jpg)

