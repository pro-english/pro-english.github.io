# Verb + preposition

1. **Revise for**

In British English, "I'm revising for my exam" is a complete and idiomatic sentence.
In British English, "I'm reviewing for my exam" is an unidiomatic sentence.
In British English, "I'm reviewing my exam" is a complete and idiomatic sentence, but it does not mean the same as "I'm revising for my exam". Revision for an exam takes place *before* the exam, whereas reviews of exams take place *after* those exams.

1. **Believe in** 
2. **Appeal to**

make an appeal to smb.

притягивать кого-л.

1. **Spend on**
2. **Invest in**
3. **Pay in cash**
4. **Pay by credit card**
5. **Pay back**
6. **Lend to**
7. **Borrow from** 
8. **Charge for** (They charged us 60 euro for a bottle of wine)
9. **Get into** (I never get into debt).
10. ​