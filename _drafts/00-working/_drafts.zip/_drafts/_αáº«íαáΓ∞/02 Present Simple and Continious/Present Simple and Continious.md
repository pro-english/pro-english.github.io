# Common

Mac Millan dictionary - хороший словарь - https://www.macmillandictionary.com/

**action use completely**

Do you know what it is? (~~Do you know what is it~~)

finally - в конце концов



can of pepsi

carton of milk

tin of meat

box of chocolate



I feel well (physical condition) - opposite "unwell"

I feel good (about mood) - opposite "bad"



I don't feel like cooking. - я не хочу готовить.



**Fruit - Countable or uncountable**

The word 'fruit' can be both. It's more often not countable."

"I want some fruit."
"I want a lot of fruit."
"Make sure you eat your fruits today." 

Individual fruits are usually countable.

"I want five pineapples."
"Please bring four apples, two bananas, and three oranges."



# Preposition

in - living

to - visit

# Future plans

Future plans - use Future Continuous - **will не использовать!**



# Present Prefect

1. Present Prefect используется without Time Reference!

   - When did they get (~~have they get~~) back from Canada?

   ​

# Present Tense

| Present Simple                                               | Present Continuous                                           |
| ------------------------------------------------------------ | ------------------------------------------------------------ |
| **1. Fact/ a habit**                                         | **1. Process which is running now**                          |
| His only bad habit is that he talks (~~is talking~~) too loudly. | if you aren't listening to the radio, why don't you switch if off? |
| **2. Regular action**                                        | **2. Temporary actions** (Действие происходит в прямо сейчас) |
|                                                              | 1. I am working on two projects now. (Even than I am learning English) 2. I'm sleeping on Niko's sofa until I find a place of my own. 3. I'm only working there for a couple of months because I'm going abroad in the summer. |
| **3. Describe actions** (we see, he goes out, he meets)      | 3. **State/action**                                          |
| So in the first scene we see (~~are seeing~~) him getting up and then he goes out (~~is going out~~) and meets (is meeting) a strange woman. | Сложная тема. Если state, то нельзя использовать continuous. Если action - то можно использовать и continuous и simple. |

![1](C:\STD\sn\Навыки\Английский язык\material\02 Present Simple and Continious\1.jpg)

![2](C:\STD\sn\Навыки\Английский язык\material\02 Present Simple and Continious\2.jpg)

##State / action

1. Если state мы используем Present Simple.
2. Eсли action мы можем использовать Present Simple и Present Continuous.

### Feel - state/action

state: I feel (think) - opinion

action: I am feeling good.

feel (в английском feel это action) - Present Continuous Preferable

We **are feeling** nice and relaxed.

### Hear - action

I am just hearing things.

### Think

What do you think? (opinion)

### Seem - state

I am writing to you from Granada where everything **seems** to be going just fine.

### Look

It **looks** absolutely magnificent! (not action, это выглядит)

### Stay

We **are staying** gorgeous hotel just down the road from Alhambra, which **is** old fortress built by the Moors.

### Stand

It **stands** at the top of the hill just opposite our hotel and we can see this wonderful building through our window.

### Cost

The hotel is lovely, but unfortunately it **costs** a lot to stay here!

### Make

It's a cold cucumber and tomato soup which they **make** with oil, vinegar and garlic and it tastes delicious.

### Taste

It **tastes** delicious.

### Shine

The sun is shining.

![3](C:\STD\sn\Навыки\Английский язык\material\02 Present Simple and Continious\3.jpg)



| State (only Present Simple) | Action (Present Simple + Present Continuous) | Both                                                         |
| --------------------------- | -------------------------------------------- | ------------------------------------------------------------ |
| know                        | clean                                        | think (я думаю - как мнение, я обдумываю сделку - процесс)   |
| understand                  | drive                                        | smell (пахнет само по себе без действия, понюхать - действие) |
| own                         | put                                          | appear (he appears to be friendly - кажется, он появился - действие) |
| like                        |                                              | look (это выглядит и смотреть за)                            |
|                             |                                              | hear (послышалось без действия, слышать)                     |
|                             |                                              | see (Do you see what I mean? like understand, и смотртеть). See it is ability (I can see). I am seeing with friends. |
|                             |                                              | come (он пришел из комнаты, she comes from Omsk (прибыла))   |

![4](C:\STD\sn\Навыки\Английский язык\material\02 Present Simple and Continious\4.jpg)



## Пример

I am living in Saint-Pertersburg.

I live in Saint-Petersburg.