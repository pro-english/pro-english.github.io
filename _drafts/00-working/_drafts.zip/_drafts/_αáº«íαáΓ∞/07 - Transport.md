# Transport

## On land

1. Van - фургон

   ![52144761419](C:\Users\0249~1\AppData\Local\Temp\1521447614191.png)

2. Tram - трамвай

3. Trolleybus - троллейбус

4. Coach - автобус между городами

5. Local train (suburban train) - пригородные поезд (загородная электричка)

- People who ride motobikes or bicycles usually just call them bikes.
- A vehicle is anything that transports people on land. 
- Lorries are sometimes called **trucks** 
  in British English and always in American English.

## On water

1. Ferry - паром
2. Rowing boat - лодка с веслами

- Ship is only used to talk about large boats.
- If you go on a ferry, you hope the crossing will be calm because if it is rough, you might be seasick.

## Air transport

1. Jet - реактивный самолет
2. Ballon - воздушный шар
3. Airship - дирижабльu