# Pronunciation

Вопросы не всегда произносятся с повышением!

![52144958380](C:\Users\0249~1\AppData\Local\Temp\1521449583807.png)

