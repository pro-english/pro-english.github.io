# Цели

1. Оформить Future Tense как материал + тест.
2. 



# Результаты

1. 26/06/18 - Итоги курса pre-intermediate - Нужно уделить внимание скорости речи.

   > Все более ле менее ровно.
   >
   > Обратить внимание на скорость речи, подзабить на грамматику!
   >
   > Английский изучается волнами, нужно прокачать часть с разговором.




# Общее

# English - Make Many Mistakes

1. **Чем больше ошибок я совершу тем больше будет что обдумать!**
2. Помните - никто не сделает из вас программиста, если вы сами не приложите к этому усилия. Цель курса - научить тех, кто хочет научиться. Результат будет зависеть только от вас! (http://digitalspace.getcourse.ru/cplus#zapisatsya)



## 26/06/18

# Learning language

	For my opinion, to learn foreign language you need to practice 4 directions: reading, listening, writing and of course specking. Reading and listening are important firstly, because you need to get information about language: words, rules, pronunciation and others. But after this you should reproduce your knowledge, you should try to write and speak.

	Paolo, Luis and Marit drill only getting information in foreign language, without reproducing. I think this way is not optimal. Kiko also makes exercises, it's next step. But Josef uses more active way to learn foreign language, he includes communication.





Link

Слова

Due to 

Juding

# Problems

1. Не понимаю когда использовать Continuous


**It will be just the same.** Это будет точно так же.

**You can forget the whole thing.** - Ты можете забыть все это.







In time - заранее, On time - вовремя. 

## the following day



## Вопросы

1) Вопросы как сказать увидимся во вторник: See you on Tuesday.

## Задания

Вводить **I am going to ...**

**Should** **I do it?**

**Should I have done it?** - Должен ли я был сделать?

get used to - привыкнуть

## Circumstances 

Under what circumstances would you cry in class?

If I had a bet I would cry in class.



### Листок 



## 31/05/18

https://www.englishclub.com/grammar/verbs-m_used-to-do.htm

Do you know what it is?



## 23/04/18

**I am under the weather**

If someone is or feels under the weather, they feel ill:

I'm feeling a bit under the weather - I think I'm getting a cold.



**whatever the amount is** - независимо от того, какая сумма

**likely** - вероятно

I didn't check my **change (сдача, мелкие деньги)** in the bar - that waiter charged me too much for the coffee.

## Who do have

And there are also a lot of people **who do have** (у кого есть) money problems who don't need to have these problems.

**Объяснение**

We do have a lot of lakes означает "у нас действительно много озёр", усиление. Это не различие американского и английского.



## 18/04/18

Proverb - погворка

Money makes the world go round. (Деньги крутят миром)

There is no such thing as a free lunch. (Бесплатный сыр в мышеловке)

Look after the pennies and the pounds take care of themselves. (Копейка рубль бережет)

Purchase - покупка

Bargain - сделака (cheep and useful)

a receipt - чек

a bill - счет

cashpoint (брит), ATM (амер) - банкомат

cash till - касса

## 12/04/18

Waste money **on** ...

People work well (~~good~~). But they are good workers.

I am not sure either (~~too~~)

Work - uncountable. You'll have work. You'll have a job.

## 05/04/18

**What the hell is going on**

**in general** - в общем.

- Yes, in general you're probably right.

  This is controversial.




# Time

In time (15 minutes early)

On time (i am not late)

2. ​






## Фразовые глаголы

**Continue:** go on, take on, carry on



![04-phrasal-verb](C:\STD\sn\Навыки\Английский язык\material\images\004-phrasal-verbs.jpg)



### Second

1. Oh, sorry to interrupt everyone, but i need to make an announcement. Everybody understands. Yes Okay, **carry on**, continue.
2. It could also mean to continue something that's been going on for a long time. So, for example, Jimmy wants to **carry on** his father's tradition of having a barbeque every Sunday.



### First

1. To look after (someone) - to care of
2. to come across (something) - to find chance - натолкнуться
3. to bring (someone) up - воспитать
   - I tried to **bring the children up/bring up the children** in a loving but strict way.
4. to look up to (someone) - to respect and admire - восхищаться
5. to pick (something) up - to learn without trying - схватывать на лету

![05-phrasal-verb](C:\STD\sn\Навыки\Английский язык\material\images\005-phrasal-verbs.jpg)

**Фразы:**

1. a natural leader - прирожденный лидер
2. stick to her opinions - придерживаться своего мнения
3. easily influenced by other people - легко попадают под влияние других людей
4. follow the crowd - следовать за толпой
5. persuade other people to do things - убеждать других людей делать что-то
6. a fashion victim - жертва моды

## Числа

### Nobody, Everybody - единственное число

1. I think nobody was ready.
2. Everybody was happy.



## Perfect Simple

### Grammar - Past Perfect

![img](https://bytebucket.org/nosovserzh/sn/raw/7bb754fc31c0117adadcbd2b4ddc773866f707e5/%D0%9D%D0%B0%D0%B2%D1%8B%D0%BA%D0%B8/%D0%90%D0%BD%D0%B3%D0%BB%D0%B8%D0%B9%D1%81%D0%BA%D0%B8%D0%B9%20%D1%8F%D0%B7%D1%8B%D0%BA/images/001_past_perfect.png?token=394e66827cab257ca4e513a2fc08dbc6945612be)

#### Type cases

- I realised + Past Perfect
- I understood + Past Perfect

#### My notes (Ошибки новичка)

- Past Perfect не ограничивается предложением, то есть можно использовать Past Perfect первым в предложении, если до этого существуют другие предложения с Past Simple, то есть все зависит от контекста.
- В Past Perfect используется 3я форма (had seen, hadn't seen), а в Past Simple - 2ая (saw, didn't saw).

#### Examples

- I went to Russia last year. I hadn't gone before.
- Why didn't you eat with them? I had my breakfask already.
- Why was the house so quiet? We had gone to bed.

### Already, yet, just

> **При использовании just, yet, already нужно всегда использовать Present Perfect!**

- **Already** и **just** используется только в утверждениях перед основным глаголом.
  - .. already V3 ..
  - .. just V3 ..
- **Yet** используется в вопросах и отрицаниях в конце предложения. (Yet значит тоже что-то и already только используется в вопросах и отрицаниях)
  - .. yet. 

**Examples**

- People have just made mistake.
- The guys have just finished to watch a film.

## Holidays

**Ошибки:**

1. Look around the museums and art galleries
2. Hire a car
3. Go sightseeing
4. Go on excursions and trips

![MG_116](C:\STD\sn\Навыки\Английский язык\material\images\002-holidays.jpg)

# Material    

### Grammar - Intesting or Intrested

| Past Simple        | Past Continues                           | Past Perfect |
| ------------------ | ---------------------------------------- | ------------ |
| S + V2             | was/were + V-ing                         | had + V3     |
| Did S + V          |                                          |              |
| S + didn't V       |                                          |              |
| Действие завершено | Не важно закончено или нет. Важен процес |              |

- The film was exciting I was excited.
- The match is interesting I is interested.

> Используй прилагательное + ed, когда речь идет о своих чувствах. Используй прилагательное + ing, когда речь идет об описании чего-либо (не тебя).

