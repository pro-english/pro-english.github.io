# Past Tense

Good article: http://www.study.ru/lessons/intermediate2-7.html

| Past Simple                                                  | Used to                                                      | Would                                                        |
| :----------------------------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
| **State and repeated actions (like used to) + single action in past.** | **State (not single action) and repeated actions.**          | **Repeated actions.**                                        |
| Если можем использовать Past Simple не обязательно можем использовать used to. | Если можем испльзовать used to значить можем использовать и Past Simple.  Но в контексте или этом же предложении должно обязательно подчеркиваться, что названное действие сейчас уже не совершается. | Если указано количество раз (мы переезжали 4 раза) нельзя использовать would. Would не переводится как должен быть, а испльзуется для обозначения прошедшего времению. Должен был - had to. |
| I broke my leg when I was a child. (Нельзя использовать used to). | **State:** I used to have a long hair. **Repeat actions:** I used to go to a kindergarten. | **Repeat actions:** I would go to school when I was a child. |
| My family moved house four times when I was a child. (Нельзя использовать would move) | **Didn't use to** - для отрицания.                           |                                                              |

![06-past-tense](C:\STD\sn\Навыки\Английский язык\material\images\06-past-tense.jpg)



![06-past-tense-examples](C:\STD\sn\Навыки\Английский язык\material\images\06-past-tense-examples.jpg)

![06-past-execuses-1](C:\STD\sn\Навыки\Английский язык\material\images\06-past-execuses-1.jpg)

![06-past-execuses-2](C:\STD\sn\Навыки\Английский язык\material\images\06-past-execuses-2.jpg)



## Не использовать would, если состояние (state)

1. The football Pele was my role model when i was growing up.
2. My older brother was my hero, but he wouldn't talk to me much.
3. My parents were very supportive of me when i was a child.

![06-past-would](C:\STD\sn\Навыки\Английский язык\material\images\06-past-would.jpg)

## 