# Unreal present future

Нереальное настоящее будующее - unreal present future

**If Past Simple, would + inf**

Example: If I found money on the street what would you do?

Раньше нужно было использовать вместо was - were. Сейчас можно и was и were. 

Но если используется If I were you, I wish I were you - нужно обязвательно использовать were.

Пример, когда можно использовать два варианта: If I was (were) rich - без разницы

![08-unreal-present-future](C:\STD\sn\Навыки\Английский язык\material\images\08-unreal-present-future.jpg)



# 