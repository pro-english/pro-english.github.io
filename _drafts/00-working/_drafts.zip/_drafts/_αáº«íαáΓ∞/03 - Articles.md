# Article

| a/an (one)                                                   | the (this)                                          | Без                                                          |
| :----------------------------------------------------------- | --------------------------------------------------- | ------------------------------------------------------------ |
| **Single, countable**                                        | **Singular/plural AND countable/uncountable**       | 1.Countable (plural) in general 2. Uncountable               |
|                                                              | Когда not general                                   | 1.**Consumers** choose... (in general). Но когда уже речь пойдет не в общем, нужно использовать **The consumers**.. |
| After to be use a/an. - There is a... There was an .. It is a ... It was ... | the произносится как **ви** перед гласным - the eye | 2. Uncountable (water). I need water.                        |

![07-article](C:\STD\sn\Навыки\Английский язык\material\images\07-article.jpg)



![07-article-exercise](C:\STD\sn\Навыки\Английский язык\material\images\07-article-exercise.jpg)

**Ошибки:**

1. Where is **the ~~a~~** toilet? It's over there. (ближайший туалет, то есть конкретный)
2. It has **a ~~the~~** really bad song. (a потому что первое упоминанине, но когда говорить to the cinema в первом упоминании, когда речь идет о куда пойдем, то используется the)
3. And a lot of the time **the ~~()~~** ads are really annoying and stick in your head. (Конкретная)

![07-article-exercise-3](C:\STD\sn\Навыки\Английский язык\material\images\07-article-exercise-3.jpg)

**Ошибки:**

1. You should eat **~~a~~** vegetables and **~~a~~** fruit as part of a healthy diet. (vegetables - plural, fruit - in general поэтому без артикля)
2. Could i speak to **~~a~~ the** manager, please? (Поговорить с кем-то конкретным, кто за это ответственный)



# Article Extend

## Имена собственные

### Water with the except lakes (Lake Baikal)

Вся вода используется с THE

- The Atlantic Ocean
- Baikal

### Ship with the

**Все названия кораблей используются с THE**

- The Titanic (ship)

### Countries

Добавляется THE, если устройство государства используется в названии:

1. States (The USE)
2. Kingdom (The United Kingdom)
3. Republic
4. Federation (The Russia Federation), but Russia
5. Исключение The Ukraina

![07-article-water-countries](C:\STD\sn\Навыки\Английский язык\material\images\07-article-water-countries.jpg)

## Учереждения

1. Prison, 
2. school, 
3. hospital, 
4. university, 
5. church

| a                          | the                                                          | without                                                      |
| -------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
| if you mean - building     | specific building (конкретную)                               | if you mean - institutions (учереждение)                     |
| I go to a church on Sunday | I go to the school to take my kids. I go to the church near my Home every Sunday. | My child is in school. He is in prison. My child is in church. |

## The .. of

Если используется конструкция the .. of, то 99% используется the

The top of building..

![07-article-building](C:\STD\sn\Навыки\Английский язык\material\images\07-article-building.jpg)



## Exercises

![07-article-exercise-2](C:\STD\sn\Навыки\Английский язык\material\images\07-article-exercise-2.jpg)

1) Can you do the shopping when you're in town?

1. **Do the + work + ing**

the shopping

the washing up

1. Почему не **the town**? так тоже можно разные оттенки.
2. **Школьные предмены без the.**

Our first lesson after lunch is **geography.**

1. Если в значение учереждения (Institutions), то без артикля.

When I leave **university** I want to be a journalist.