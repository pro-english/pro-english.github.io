# Reported Speech

![09-reported-speech](C:\STD\sn\Навыки\Английский язык\material\Grammar\01 Reported Speach\images\09-reported-speech.jpg)

## Said/Told

He said (to smb - необязательная часть)

He told  who (smb - обязательная часть)





