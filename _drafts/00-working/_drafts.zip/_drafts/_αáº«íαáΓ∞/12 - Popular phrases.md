# Popular phrases

1. Good to hear.
2. See you on Tuesday.
3. Get used to - привыкнуть
4. Under what circumstances would you cry in class?

