# Time

Time: 4 of 2, it means 13:56