## 15/10/2019

[Lask link](https://docs.google.com/document/d/1i-Xn5PG-ilJjjNoXMiFblwPUZr6AhFkdmoh1gmy00T8/edit)

HW: p. 21-22, unit 19

1. That depends on
2. Get back to you
3. a range of possibilities
4. it's hard to say
5. room for manoeuvre
6. draw up a quotation
7. to follow up on our conversation



**Unit 7**

1. If they gave us more time, we would be able to look at our logistics problems in more detail.
2. I'll give you a 13% discount if you place your order today.
3. I would be prepared to place the order if you offered us a better after-sales service deal.
4. If we confirm the job offer today, he'll be able to start work at the beginning of the month.
5. if I came to your team meeting at 10 am, would I be able to leave at midday? I have another appointment to get to.



**Unit 19**

1. date and time
2. held
3. present
4. were
5. achieved
6. were
7. each
8. deadlines
9. distributed
10. all documentation
11. details (venue)





## 10/10/2019

- Private village

- Private island

- Новые дубки

- Gated community

- subdivision
- Private island
- membership
- gate
- Guest pass
- developments
- Gated community
- subdivision
- I’m swamped with work - очень устал
- I’m overwhelmed with work
- keep working on it
- date
- that assign for me
- 





## 18/07/2019

1. От Karyn McCrimmon всем:  06:16 PM

2. priest

3. minister

4. Justice of the peace

5. sit down dinner

6. buffet

7. dancing

8. music

9. dj

10. toasts

11. Best man

12. husband wife

13. Wife and her father

14. toasts

15. Break bread

16. break glass

17. wedding

18. Reality YV

19. Bridezilla

20. flowers

21. Closest relatives

22. https://www.achapeloflove.com/

23. elope

24. run away secretly in order to get married,

25. Elvis Presley

26. Impersonators
    От меня всем:  06:18 PM
    While I was driving on the freeway,I saw a horrible accident, but I couldn't look in! 
    От Karyn McCrimmon всем:  06:23 PM
    : ENGAGE, HIRE
    3a : to assume or acquire as or as if one's own
    Take on
    Take in transitive verb

    1a : to receive as a guest or lodger
    b : to give shelter to
    От Karyn McCrimmon всем:  06:30 PM
    When St Petersburg has a festival, it takes on a festive vibe.
    acquire
    Take in live with you as a renter
    take in understand information
    Our company needs to take on more staff.



## 16/07/2019

grudge
a persistent feeling of ill will or resentment resulting from a past insult or injury.



## 02/07/2019

### [9 Habits of Highly Effective Language Learners]([https://bit.ly/2xlC01p](https://mail.lanit-tercom.com/owa/redir.aspx?REF=oYM31UUWZMTIxOUUcK3J2GXBJ8npmNkwc6cCRH0EPHCC0old-f7WCAFodHRwczovL2JpdC5seS8yeGxDMDFw))

Как выучить Английский!

- Люди не умнее, у них просто есть привычки.
- У них есть **регулярные** привычки.
- Лучше учить немного каждый день, а не один раз долго в месяц.
- Proceed.
- New vocabulary!
- **To reveiw** that you leart
- **Make clear goal!**
  - Tofell
  - 10 new worlds in a week.
- Take risk. **Taking risk**. Not afraid -> make mistake.
- Mistake helps to learn.

----

## Habits

will serve you well

- being regular
- reviewing what you learn
- setting goals
- taking risk



- listen and read interesting information --learn interesting information to keep a motivation

- writing things down

- need to keep balance between input and output information, it means that you should speak a lot, but also you need to listen new wordsб need to listen and also speak

- need to imitate native speakers

- need to practice produce a language

  

loose motivation

taking advantage

what's why you should 



---

asdas

Also, the ice-breaker is to discuss your favorite vacation destination.



greak people

- armenia
- Turkey

- Turkish

I understand that I don't like common vacation like to get package tour in Turkish and have a rest in hotel.

For me more attractive to go 

For example, my the lask adventure was in Armenia, there were 4 people in our group, we rented a car. And we traveled many places in Armenia. We drove around the Sevan it's a big lake, they are called it "Армянское море" 

proposal

there are a lot of 

musel - cherch

it's named







