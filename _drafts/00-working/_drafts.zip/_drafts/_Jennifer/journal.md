# Journal

# 21/10/2019

**Essay - Stewed fruit “apple”**

Actually, I don't have a clue on how stewed fruit “apple” is being prepared. I have never done it :)

I assume the ingredients needed to make this are: pan, water, apples, some sugar and some tasty flavour. 

Procedures
 Add 2 liters of water into the pan and place it on the stove for it to boil. After that you add the 1 kilogram of clean apples and some sugar into the boiling water for 5 minutes on a medium heat; You can as well add some tasty ingredients if necessary although it isn’t compulsory. 

Then put off the gas and place the prepared stewed fruit on a cold surface for it to cool afterwards you can reserve it in the refrigerator. You can serve it cold or warm either ways it goes.

Enjoy the lovely homemade stewed fruit.



# 13/10/2019

**Esse - Weather SPB**

The weather today was quite usual for all season in Saint-Petersburg. Of cause it was rain. The trees have red-yellow dresses and the sky was full of tears. But for me rain is not always awful weather, sometimes I like to watch through window on a dropping water. But today I wanted to walk and to think by myself. When I came out the rain was going and I felt grief, because I was scared to wet my clothes and get cold. But I decided to walk anyway. I walked 1km and I felt that I wasn't wet a lot and rain wasn't powerful and I could to enjoy running. I was running through the rain and I felt awesome, it was a excellent day.



# 30/09/2019

## Perfect

1. How long have you been married?
   - I've married for ~~1~~**a** week.
2. I have lost my key. And I still ~~don't have~~ **can't find** it.
3. Have you ever been to China?
   - Yes, I have.
4. How long ~~it~~ has **it** been raining?
   - It has been raining since morning.
5. How long have you been waiting **for** me here?
   - I have been waiting ~~you~~ for ages.
6. Have you ever driven **a** car?
   - No, I haven't, It ~~is~~ will be the first time.
   - Actually, it is the first time.
7. Has John done his homework?
   - ~~No,~~ he is still doing.
   - He's on it. 
   - He's doing it, but not yet done.
8. Has Mary been waiting **for** him?
   - No, she has gone already.



# 15/07/2019

- Watch out for the green snakes under the green grass; be careful who you make your friend.
  - My mother always said "Watch out for the green snakes under the green grass". That means "be careful who you make your friend".
- Life is like a roller coaster.
  - I relocated to the New York and my life is like a roller coaster.
- Hit the nail on the head
  - Join solved his math task
- Let the cat out of the bag 
  - My friend have never let the cat out of the bag. I can tell him everything.
- Kick the bucket
  - He was living very dangerous life. It was written on the wall that he kicked the bucket.
- Pass out (fast asleep)
  - I was very tied. I passed our when I went home.



# 29/05/2019

## [20 English Phrasal Verbs For Communication](https://www.espressoenglish.net/20-english-phrasal-verbs-for-communication/)

1. fess up - сознавайтся
   - Where were you? Fess up.
2. talks down - говорить наставляющим тоном
   - My father always talks down to me, like I am still a child.
3. speak up - вызсказываться
   - If you don't like something, you should speak up.
4. tune smb out - не обращать внимания
   - John said that pupils tease him in school. His mom: "Try to tune their out! Going forward they will stop".
5. called him out - вызывал
   - The headteacher called John out, because John broke the window.
6. pointed out - указал, отметил
   - I just pointed out that I've been done this task.
7. spell out - разъяснять, растолковывать
   - Teacher spell out math task which will be add on exam.
8. cut me off - прервать
   - Please, don't cut me off, I want to explain.



# 15/05/2019

1. Describe a situation when you were “walking on eggshells”
   - I was walking on eggshells, when I was getting post graduate education. Because I had problem with my diploma work.
2. Have you ever bitten off more than you could chew? What happened?
   - Of course, sometimes I am optimist and I give estimation about working task less then it's needed.
3. What are some things that are not your cup of tea?
   - I don't like going in museum without goal, for me mostly it's boring.
4. Do you know someone who’s a sharp cookie? How about a tough cookie? Describe these people.
   - I know some sharp cookies, they are very kindly and intelligent people.
   - Also I know tough cookie, one of them is my colleague. He is a brave man.
5. When was the last time you were in a pickle?
   - My girlfriend was in a pickle when she had an accident.



# 14/05/2019



**Beautiful bird** (Think of/about/over/through/ahead/back/up/to)

While John was taking a walk at the park, he thought about his future plans to buy a brand new car but he didn’t have enough money to get one.  He likes to think back when he was a little boy; him and his father once drove in the car together.

John is too rich to buy a brand new car at this moment but he has a plan. He needed to **think up** of  his business logo and suddenly he saw a bird, he **though of** a logo and he decided to create one like this bird.

**-- continue**

After some months he opened the bakery successfully and his deals went well. He **remembered of** about the bird that inspired him and he was happy that to start his own business. He **think about** second bakery on the next street. It is the very good place with many people on it, because place is near the university and the metro station. But to open second bakery he need a lot of money, and he **think up** how to get 10 000 dollar's on it. He knows one rich man who can borrow him this amount. Last months he thought over his presentation for him and they should met in one week. 



# 08/04/2019

# Think  - Разобрать

### **Think about / Think of**

The two most common prepositions used after the verb “think” are “about” and “of.” They are very similar, but there is a small difference. Usually when you “think of something,” it is a brief moment – just a few seconds. It is also used for opinions. When you “think about something” you are considering it for a longer time – like a few minutes or more.

Every time I hear this song, I **think of** my mother.
 *(thinking for a few seconds)*

What do you **think of** my new haircut?
 *(opinion)*

I’m **thinking about** moving to a different city.
 *(considering)*

I still get angry when I **think about** all the rude things my sister said to me.
 *(thinking for a few minutes or more)*

#### **Common error: Don’t use “think to” for “considering.”**

§  I’m **thinking to do** an intensive English course in Canada.

§  I’m **thinking about doing** an intensive English course in Canada.

### **Think over / Think through**

Use the prepositions “over” and “through” when you need to consider a topic carefully or think about it for a longer time (hours, days, or weeks).

§  I’m not sure which course I want to take. Let me **think it over** for a while.

§  I’ll need some time to **think through** your proposal. Can I call you back next week?

### **Think ahead / Think back**

The preposition “ahead” is used for thinking about the future:

§  We need to **think ahead** at least five years if we want our company to have long-term success.

The preposition “back” is used for thinking about the past:

§  I like to **think back** on my college years; that was a great time in my life.

### **Think up**

“Think up” is an expression that means to imagine, invent, or create an idea.

§  We need to **think up** a way to distract Laura while we plan her surprise party.

§  I spent half an hour trying to **think up** a good excuse for why I was late to work.

§  Let’s **think up** some new strategies for increasing sales.

### **Think to**

“Think to” is most frequently used with “myself” – when you think about something, but you don’t say it or share it with any other person. “Think to myself” is often followed by a direct statement of the thought.

§  Whenever I’m in a meeting at work, **I think to myself,** “This is a huge waste of time.”

“Didn’t think to” can also be used when something did not even enter your mind.

§  Sorry I didn’t see your message – I **didn’t think to** check my e-mail before I left the house.

§  I’m annoyed because all my friends went to the movies and **didn’t think to** invite me.



All through
Easy going
Differ
It differs
Plead / beg
Angelic voice



## 10 Phrases for Agreeing

1. Exactly. 

2. Absolutely. 

3. That’s so true. 

4. That’s for sure. 

5. I agree 100% 

6.  I couldn't agree with you more. 

7. That’s exactly what I think. / That’s exactly how I feel. 

8. (informal) Tell me about it! / You’re telling me! 

9.  (informal) I’ll say! 

10. I suppose so. (use this phrase for weak agreement – you agree, but reluctantly)

  Note: Avoid the common error of saying “I’m agree” – the correct phrase is “I
  agree” or “I’m in agreement” – the second one is more formal.

## 10 Phrases for Disagreeing

1. I don’t think so. 

2.  I beg to differ.

3. I’m afraid I don’t agree. 

4. I’m not so sure about that. 

5. That’s not how I see it.

6. Not necessarily. 

7. Yes, but… [say your opinion] 

8. On the contrary. 

9. (very informal) No way! 

10. (very strong) I totally disagree.



# Think of/about/over/through/ahead/back/up/to

1. I **think of** my brother always when i see this cup (because it's his present).
2. Do you want to go on carting this Friday?
   - Good idea, but i should **think about** it.
3. Do you remember you classmates?
   - Yes, of cause, i like **thinking back** my school years.
4. What are going to do tonight?
   - I am going **thinking ahead** my project.
5. Hi, we need estimating this feature? Could you do it?
   - Okay, but it's tricky, i should think over/through it during today and might be tomorrow.
6. Guys, we should **think up** something intresting for our guests, we shouldn't be bory.
7. I **think to** cook something, because I'm starving.



## 08/04/2019

1.	But now don't think about that darling.
2.	Creating your password  think about making it hard to trace.
3.	I just think of you
4.	I would never think of harming my wife.
5.	I like to think ahead.
6.	Think back when you were just a kid.
7.	When did you start to think up this plan?
8.	Of course he did not think to close the curtains.



## 30/03/2019

### 5 Ways to Check if the Other Person Understands You 

1. Do you understand what I’m saying?
2. ~~Does that make sense?~~ 
3. Do you know what I mean? 
4. Are you with me so far? (often used in the middle of a long explanation or instructions) 
5. Is that clear? (often used after giving orders, or expressing disapproval or another negative attitude) 

### 5 Ways to Ask for Help 

1. ~~I need a little help.~~ 
2. ~~Could you help me out?~~
3. Could you give me a hand? (usually used for physical tasks) 
4. ~~Could you spare a couple minutes?~~ 
5. Could you do me a favor?



### Examples

1. Could you help me out? Where is a toilet? 
   - It is there.
2. We are going redesign our architecture, does that make sense?
   - Yes, seems it will be better.
3. I need a little help, could you give me a pencil, please?
   - Yes, take it. (This person is giving a pencil)
4. Could you spare a couple minutes? Do you on a car today? I need to transfer special parcel to second office.
   - No, sorry, today I am not on a car.
5. You should keep this document and deliver it to post office.. Do you understand what I’m saying? 
   - Yes, no problem.

 

### Exercise 2 – Now complete the blanks with must, should, shouldn’t, or couldn’t: 

1. I'm so thankful for your help with this project. I **couldn't** have done it without you! 

2. The repairs I made **should** have fixed the problem, but they didn't - so I'll have to take another look. 

3. It **must** have rained a lot last night - there are puddles everywhere.

4. I **shouldn't** have watched that horror movie; it gave me nightmares.

5. We **couldn't** have known about this; nobody told us anything about it. 

6. If you’ve been trying to lose weight, then you really **shouldn't** have eaten all that ice cream. 

7. He **couldn't** have finished a 500-page book in a single day! 

8. She never showed up. She **must** have forgotten about our appointment. 

9. He broke two of the plates while washing the dishes. He **should** have been more careful. 

10. They ate every bite of their dinner - they **must** have enjoyed the food.

    

Think of/about/over/through/ahead/back/up/to

1. I **think of** my brother always when i see this cup (because it's his present).
2. Do you want to go on carting this Friday?
   - Good idea, but i should **think about** it.
3. Do you remember you classmates?
   - Yes, of cause, i like **thinking back** my school years.
4. What are going to do tonight?
   - I am going **thinking ahead** my project.
5. Hi, we need estimating this feature? Could you do it?
   - Okay, but it's tricky, i should think over/through it during today and might be tomorrow.
6. Guys, we should **think up** something intresting for our guests, we shouldn't be bory.
7. I **think to** cook something, because I'm starving.



## 25/03/2019

## 10 Phrases for Asking for Information

1. Can you tell me...? 
2. Could you tell me...? 
3. I&#39;d like to know... 
4. Do you know...
5. Do you have any idea...? 
6. Could anyone tell me...? (use this phrase when asking a group of people)
7. Would you happen to know...? 
8. I don&#39;t suppose you (would) know...? 
9. I was wondering… 
10. I’m calling to find out… (use this phrase on the telephone)

*Use #4, #5, #7, and #8 when you’re not sure if the other person has the information.*

## 5 Ways to Say “I don’t know”

1. I have no idea/clue. 
2. I can’t help you there.
3. (informal) Beats me. 
4. I’m not really sure. 
5. I’ve been wondering that, too.

## 10 Phrases for Asking for Someone’s Opinion &amp; Giving Your Opinion

1. What do you think about...? 
2. How do you feel about…? 
3. What&#39;s your opinion of...? 
4. What are your views on...? 
5. In my opinion… 
6. I&#39;d say...



## Examples

1. Could you tell me price of this chocolate?
   - I'm not really sure, seems it cost around 1$.
2. I'd like to know how you passed this exam?
   - I have no clue, it is lucky, because I didn't prepare.
3. Can you tell me what is the answer?
   - Beats me.
4. Would you happen to know what time is now?
   - I have no idea.
5. I was wondering about future adventure to Bali.
   - I’ve been wondering that, too.
6. I was wondering how the Earth was appeared?
   - I’ve been wondering that, too.
7. I’m calling to find out how long we should wait a courier?
   - Sorry, I can't help you there, seems you are wrong with number..



## 24/03/2019

### You are boss. Pron/Cons

Pron

1. Boss is main in his business.
2. Boss decides direction to improvement his company.
3. Boss gets the most part of profit.

Cons

1. If something goes wrong, boss should find decision.
   - If company has no money/clients, Boss should resolve such situation.
2. Boss can be under big pressure from different problems.
3. Boss should decide all big problems if his employers can't do it.



## 16/03/2019

1. What topic are both photos connected to?

   - The topic of these photos is family.

2. How are these pictures similar?

   - The pictures are similar because the photos show happy family on a nature (might be on vocation).

3. How are these picture different?

   - The pictures are different in count of people in family, also on family have only white people, seems with the same race, but another family have father African man, and wife is Asian woman.

4. What are the advantages/disadvantages of small/big families?

   - Advantages of big families that people have many persons to communicate and to care about each other.
   - Disadvantages of big families that.. When family have a lot of people, children get less attention from parents. Also big families required more resources for each person.
   - Advantages of small families that child gets a lot of attention from their parents.
   - Disadvantages of small families that .. if child is single in family, child doesn't communicate with his brothers and sisters.

5. What about your family? What about families in your country?

   - My family has father, mother and two sons: me and my brother. I suppose that It is quite common case in Russia that family has two or one child.

6. Would you prefer to have a big or a small family?

   - I would prefer to have a big family because for me it is more interesting.


## 03/03/2019

This is a story about my adventure in the Crimea. I had been in the Crimea in May of 2018. Firstly we should to arrive to the Moscow. After that we started to drive to the Crimea on a car. There were four people of us. In 2018 there is not a Crimea bridge and we used ferry to get to the Kerch. We were going from Moscow and watching how to change climate and picture though car window, because Moscow spring and Crimea spring are the different things. In the Moscow we could see only snow and dirty, but the Crimea was already really green with tree and flowers.

At the beginning we had a climb trip in the Sudak, we climbed to the rocky mountain with special equipment. It was quite fearfully, but also cool. We had been in the Sudak 3 days, and we created two climb trips.

Also we had visited Feodosia, Koktebel, Alushta, Yalta, Balaklava, Semferomol. We have appeared a tradition to take a see trip in every different new town. As i remember, we had 4 see trips in this adventure. 

It was quite various tour, because sometimes we slept under a tent, in another day it might be a hostel. Sometimes we ate food which we made ourself, sometimes we ate in restaurants.

We had visited almost south coast of the Crimea. It was cool adventure.









## 26/02/2019

### 94.2 Read the situations and complete the sentences using where.

1. You grew up in a small town. You went back there recently. You tell someone this.
   I recently went back to the smciil town where I grew up.
2. You're thirsty and you want a drink. You ask a friend where you can get some water.
   Is there a shop near here **where i can get some water?**
3. You work in a factory. The factory is going to close down next month. You tell a friend.
   The factory **where I work** is going to close down next month.
4. Sue is staying at a hotel. You want to know the name of the hotel. You ask a friend.
   Do you know the name of **the hotel where Sue is staying**? 
5. You play football in a park on Sundays. You show a friend the park. You say:
   This is the **park where i play football** on Sundays.

### 94.3 Complete each sentence using who/whom/whose/where.

1. What's the name of the man whose car you borrowed?
2. A cemetery is a place **where** people are buried.
3. A pacifist is a person **who** believes that all wars are wrong.
4. An orphan is a child **whose** parents are dead.
5. What was the name of the person to **whom** you spoke on the phone?
6. The place where we spent our holidays was really beautiful.
7. This school is only for children whose first language is not English.
8. The woman with **whom** he fell in love left him after a month.

### 94.4 Use your own ideas to complete these sentences. They are like the examples in Sections D and E.

1. I can't meet you on Friday. That's the day i'm going away.

2. The reason **why I decide to leave my company It** was that the salary was too low.

3. I'll never forget the time **that we got married.**

4. Do you remember the day **when you broke your car**?

5. The reason **that the sold the bike It** is that they don't need one.

6. **It** was the year **ago when you bought new motorbike.** 


## 20/02/2019

~~in~~ | on | at | ~~to~~ | ~~into~~

1. I am going to go to a bar at the conner Griboedova street.
2. There are a lot of toys into this box.
3. How much does it cost to go to the airport?
4. Have you ever been in New York? No, never, but I have visited US twice.
5. How much degrees in this room? Temperature in this room is about 20 degrees.
6. Could you give a lift me at the cinema? Sorry, this is not the way.
7. The Neva goes into Finland bay.
8. I saw you at the concert on Saturday.
9. I will be busy at 9:00.
10. I will be at work.

## 16/02/2019

**2 sentences with at/in/on**

1. You shouldn't go **on** a bus. We can give a lift you. We are going **at** the airport **in** the car. (to the airport?)
2. Where is the Eiffel Tower **in** Paris? Can we get there **on** a bike?
3. Does a bus arrive at the station **at** 8 o'clock? How long to go **at** the station from here? (to station?)

## 08/02/2019

**126.2 Have you been to these places? If so, how many times? Choose three of the places and write a sentence using been to.**

Athens Australia Hong Kong Mexico Paris Rome Singapore Sweden Tokyo the United States

2. I've never been to Rome.
3. I've never been to the United States.
4. I had been to Paris when I was a child.

**126.3 Put in to/at/in where necessary. If no preposition is necessary, leave the space empty.**

1. What time does this train get **to** London?
2. We arrived **in** Barcelona a few days ago.
3. What time did you get **home** last night?
4. What time do you usually arrive **at** work in the morning?
5. When we got **to** the cinema, there was a long queue outside.
6. I arrived **home** feeling very tired.

**126.4 Write sentences using got + into / out of / on / off.**

1. You were walking home. A friend passed you in her car. She saw you, stopped and offered you a
   lift. She opened the door. What did you do? I got Into the car.
2. You were waiting for the bus. At last your bus came. The doors opened. What did you do then?
   I **got on** the bus.
3. You drove home in your car. You stopped outside your house and parked the car. What did you
   do then? **I got out of the car.**
4. You were travelling by train to Manchester. When the train got to Manchester, what did you do? **I got off the train.**
5. You needed a taxi. After a few minutes a taxi stopped for you. You opened the door. What did
   you do then? **I got into the taxi.**
6. You were travelling by air. At the end of your flight, your plane landed at the airport and
   stopped. The doors were opened, you took your bag and stood up. What did you do then? **I got off the plane.**

**126.1 Put in to/at/in/into where necessary. If no preposition is necessary, leave the space empty.**

1. Three people were taken **to** hospital after the accident. 
2. I met Kate on my way **~** home, (no preposition)
3. We left our luggage **at** the station and went to find something to eat.
4. Shall we take a taxi **to** the station or shall we walk?
5. I have to go **to** the bank today. What time does it open?
6. The Amazon flows **into** the Atlantic Ocean.
7. 'Do you have your camera with you?' ‘No, I left it **in** the car.
8. Have you ever been **to** China?
9. I had lost my key, but I managed to climb **into** the house through a window.
10. We got stuck in a traffic jam on our way **to** the airport.
11. We had lunch **at** the airport while we were waiting for our plane.
12. Welcome **to** the hotel. We hope you enjoy your stay here.
13. We drove along the main road for about a kilometer and then turned **to** a narrow
    side street.
14. Did you enjoy your visit **to** the museum?
15. I'm tired. As soon as I get **home**, I'm going **to** bed.
16. Marcel is French. He has just returned **to** France after two years **in** Brazil.
17. Carl was born **in** Chicago, but his family moved **to** New York when he was three.
18. He still lives **in** New York.





## 02/02/2019

assonance, same, equal, correspond, goes in accordance

objection

I am not accepting your idea because it doesn't correspond with mine.

I object Sergey's idea because it differ from mine.

I am objecting his idea because it not in accordance.

Resurrect (risen)

CPR

revive - оживать

How are you faring with you health?

How a re you faring with your job?

fair / unfair 

acquaint- meet first time

I am not acquainted to this book.

Demand / need / insist

Want ... have alternative

Need ... not alternative

Discourage / mislead / misguide

She discourage me on going my way.

## 02/02/2019

1. I have a **precise** watch.
2. The speech should be **concise**.
3. He didn't sleep last night, because he is such **moody** (**cranky**).
4. The hely with people achieves a **upmost** height, further the team will go themself.
5. I'm sure you will pass all exams with **flying colors**.
6. He passed this course and he got a **plaque**.
7. He became a very **suspicious** after this journey.
8. We were in a bar, and **rumor**(**murmur**) was very loud.
9. This woman is **plumpy** (**chubby**).
10. This climate is **conducive** for me.

## 28/01/2019

1. He is very famous, he leads a **luxurious life**.

2. Her name **assonances** with your's.

3. Some people have **objections**, because they's salary isn't increased, but taxes are increased.

4. The Jesus **resurrected**.

5. How was going your **acquaintance** with him?

6. There are a lot of **remonstrances** in this year.

7. They sue me, because they think that I broke the law. But I didn't, I just did my job.

8. People **demand** not to increase retirement age.

9. His behavior was **unbecoming**, i am going to sue **him**.

10. Mother **discourage** her daughter to go in this dangerous journey.


## 26/01/2019

**Words:**

- bulky
- dismantle
- abide (obey)
- stick
- stuck

**10 sentences:**

1. She likes wearing a bulky sweater.
2. How do you build muscle without getting bulky?
3. Workers dismantled the old building near my home.
4. I would like dismantle my PC and change power supply, because it is noisy and it annoys me.
5. People abide the public lows.
6. She abides her diet, because she wants to keep herself in fit.
7. He doesn't stick his words.
8. People should stick public lows.
9. Skype stucks.
10. His car stuck in this forest.



## 21/01/2019

1. Would you like to go for snow boarding?

2. Would you like a cup of tea?

3. Do you think I could go with you on this event?

4. Could I help you?

5. Can I take this place?

6. Can you borrow some money, please?

7. May I stand here and I don't go with you.

8. May I taste this chocolate cake?


## 12/01/2019

**36.5 Complete the sentences. Use wouldn't + a suitable verb.**

1. I tried to warn him, but he wouldn’t listen to me.
2. I asked Amanda what had happened, but she **wouldn't answer** me.
3. Paul was very angry about what I'd said and **wouldn't tell** to me for two weeks.
4. Martina insisted on carrying all her luggage. She **wouldn't allow** me help her.

**36.6 These sentences are about things that often happened in the past. Complete the sentences
using would + these verbs: forget-help-shake-share-walk**

1. Whenever Richard was angry, he **would walk** out of the room.
2. We used to live next to a railway line. Every time a train went past, the house **would shake.**
3. Alan was a very kind man. He **would** always **help** you if you had a problem.
4. Katherine was always very generous. She didn't have much, but she **would share** what she had with everyone else.
5. You could never rely on Joe. It didn't matter how many times you reminded him to do
   something, he **would** always **forget**.



## 18/12/2018

33.3 Are these sentences right or wrong?

1. Tom suggested that I should look for another job. OK

2. Tom suggested that I look for another job. **ОК**

3. Tom suggested that I looked for another job. **look**

4. Tom suggested me to look for another job. **~~to~~**

5. Where do you suggest I go for my holiday? **OK**

6. Where do you suggest me to go for my holiday? **~~to~~**

7. Where do you suggest I should go for my holiday? **OK**


33.4 Complete the sentences using should + the following:
ask ~~be~~ leave listen say worry

1. It's strange that he should be late. He's usually on time.
2. It's funny that you **should say?** that. I was going to say the same thing.
   - It's funny that you **say?** that. I was going to say the same thing.
3. It's only natural that parents **should be worry** about their children.
4. Isn't it typical of Joe that he **should leave** without saying goodbye to anybody?
   - Isn't it typical of Joe that he **leaves** without saying goodbye to anybody?
5. I was surprised that they **should ask** me for advice. What advice could I give them?
   - I was surprised that they **asked** me for advice. What advice could I give them?
6. I'm going to give you all some essential information, so it’s important that everybody **should listen**
   very carefully.



## 15/12/2018

1. I'm feeling sick. I ate too much. I shouldn t have eaten so much.

2. That man on the motorbike isn't wearing a helmet. That's dangerous.
   He should be wearing a helmet.

3. When we got to the restaurant, there were no free tables. We hadn't reserved one.
   **We should have reserved table.**

4. The notice says that the shop is open every day from 8.30. It is 9 o'clock now, but the shop isn't
   open yet. **They should change notice.** **(They should have changed notice.)**

5. The speed limit is 30 miles an hour, but Kate is doing 50.
   **She shouldn't break the low.**

6. Laura told me her address, but I didn’t write it down. Now I can't remember the house number.
   **I should have written down address.**

7. I was driving behind another car. Suddenly, the driver in front stopped without warning and I
   drove into the back of his car. It wasn't my fault.
   **The driver in front shouldn't have stopped so fast.**

8. I walked into a wall. I was looking behind me. I wasn't looking where I was going.

   **I should have looked in front.**



## 11/12/2018

**Present simple**

1. Assignment is done today.
2. It is made in China.

**Past simple**

1. I was born in Russia.
2. A book was written in Russian.

**Present continuous**

1. A book is being written about 1 years.
2. Street is being lighted by moonlight.

**Past Continuous** 

1. The main road was occupied for 3 hours. 
2. The house was being built during 2 years.

**Present Perfect**

1. Assignments have been done.
2. A song has finished on radio.

**Past Perfect**

1. I had already finished my job when she called me.
2. She had chosen a dress when I came to shop. 



## 10/12/2018

Complete these sentences with the following verbs (in the correct form):
arrest carry cause -do- make repair -send- spend wake up

Sometimes you need have (might have, should have etc.).

1. The situation is serious. Something must be done before it's too late.
2. I should have received the letter by now. It might have been sent to the wrong address.
3. A decision **will not be made** until the next meeting.
4. Do you think that more money **should have spent** on education?
5. This road is in very bad condition. It **should have repaired** a long time ago.
6. The injured man couldn't walk and had **to be carried**.
7. I told the hotel receptionist I **wanted to be waked up** at 6.30 the next morning.
8. If you hadn't pushed the policeman, you **wouldn't be arrested**.
9. It's not certain how the fire started, but it **might be caused** by an
   electrical fault.



## 02/12/2018

**Put the verb into the correct form, present simple or past simple, active or passive.**

1. It's a big factory. Five hundred people **are employed** (employ) there.
2. **Did somebody clean** (somebody / clean) this room yesterday?
3. Water **covers** most of the earth's surface.
4. How much of the earth's surface **is covered** by water?
5. The park gates  are locked at 6.30 p.m. every evening.
6. The letter **was sent** a week ago and it **arrived** yesterday.
7. The boat hit a rock and **sinked** quickly. Fortunately everybody **was rescued**.
8. Robert's parents **died** when he was very young. He and his sister
   **were brought up** by their grandparents.
9. I was born in London, but I **grew up** in Canada.
10. While I was on holiday, my camera **was stolen** from my hotel room.
11. While I was on holiday, my camera **disappeared** from my hotel room.
12. Why **did Sue resign** from her job? Didn't she enjoy it?
13. Why **was Ben fired** from his job? Did he do something wrong?
14. The company is not independent. It **is owned** by a much larger company.
15. I saw an accident last night. Somebody **called** an ambulance but nobody
    **was injured**, so the ambulance **didn't need**.
16. Where **were these pictures taken**? In London? **Did you take** them, or somebody else?
17. Sometimes it's quite noisy living here, but it's not a problem for me -
    I **am not bothered** by it.

**Rewrite these sentences. Instead of using somebody, they, people etc., write a passive**
**sentence**

1. Somebody cleans the room every day. The. room is cleaned every day.
2. They canceled all flights because of fog. **AIl flights were canceled due fog.**
3. People don't use this road much. **This road isn't used much by people.**
4. Somebody accused me of stealing money. **I was accused of stealing money.**
5. How do people learn languages? **How are languages learned by people?**
6. People warned us not to go out alone. **We were warned not to go out alone by people.**



## 25-19/11/18 - HW

Construct 2 sentences with  each

1. Convince 
   - I convince her to go to Paris with me.
   - She wouldn't go to Paris if she didn't know me. (but she know me a lot of time)

2. Apparently (Obviously, Clearly)
   - Apparently she will go to Paris with me.
   - Obviously it will be a good holiday.

3. Barged into
   - Police barged into their house.
   - If police found illegal things, police would arrest them. (but police didn't find anything)

4. Yell
   - What would you do if I yelled on you?
   - If she yelled on me I wouldn't understand anything. (but she didn't yell on me)

5. Confront
   - He would confront with her, if she yelled on him. (but she didn't yell on him)
   - They confronted because they have different values.
6. Assure
   - I had been assured that I would have a lot of time to do my home work. (but no)
   - I assured her to go with me.

7. In spite (Despite)
   - In spite that he was late a daily started on time.
   - Despite I assured Jeniffer that I would do a homework I didn't do it :)  (Context - previous lesson)

9. Consume
   - People consume a lot of food.
   - Consumers are satisfied with quality of our product.

10. Patronize
    - They patronize us, they always buy food in our market.
    - Omsk government patronize Omsk area. 

11. Appointment
    - She would make an appointment if she wanted. (but she didn't make it)
    - She would make an appointment if she wasn't ill. 

12. Nonsense
    - He often say nonsense, people don't understand him.
    - If he didn't say nonsense, people would understand him.

14. Literally (буквально), Basically (в основоном)
    - He took it literally, but it was joke.
    - Basically holidaymakers go to this restaurant to dance.

15. Drain
    - I was drained of all energy.
    - If he drained the swimming pool, we couldn't swim in it. (but he didn't drain the swimming pool)



## 19/11/18

Как сделать вопрос при воображаемой ситуации?

What would you do if...



Police barged into my room.

Yelling.. screaming.. shouting. Stop yelling.

Inquisitive.. curious.. wanted to know - любознательный

drain your energy (exhausted)

sick of her questions

literally.. exactly.. 

annoying

confront 

nonsense..bullshit..

brave enough

wise

stand still

you aren't a man of your word

Apparently.. Clearly.. Obviously

Meter

Consumed, comsumer

i would go and turn off the meter.

appointment

I would still go

Despite It's raining I would still go to work.

In spite.. regardless.. 

No matter how bad the weather is.

if their business is safe in your hands.

i would put more effort in that I can.

Convince.. assure

I would do my best

Yes i Assume you

Patronize.. Support

I am drained in happiness

i am overwhelmed

My effort is going in vain - 









## 15/11/18

**Home work**

1. I don't know many people (and I'm lonely). I wish I knew more people.
2. I don't have a computer (and I need one). I wish i had a computer.
3. Helen isn't here (and I need to see her). I wish i saw Helen.
4. It's cold (and I hate cold weather). I wish It wasn't cold.
5. I live in a big city (and I don't like it). I wish I lived in countryside. 
6. I can't go to the party (and I'd like to). I wish I wouldn't be able to go to the party.
7. I have to get up early tomorrow (but I'd like to sleep late). I wish i would get up early tomorrow.
8. I don't know anything about cars (and my car has just broken down). I wish i didn't know about car.
9. I'm not feeling well (and it's not nice). I wish i wasn't feeling well.



Write your own sentences beginning I wish ... .

1. (somewhere you'd like to be now - on the beach, in New York, in bed etc.)
   - I wish I went in bed :)
2. (something you'd like to have - a motorbike, more friends, lots of money etc.)
   - I wish I had a lot of money.
3. (something you'd like to be able to do - sing, travel more, cook etc.)
   - I wish I traveled more.
4. (something you'd like to be - beautiful, strong, younger etc.)
   - I wish i didn't know English fluently.



## 11/11/18

**My note**

How have you been doing (fairing with your health) ?

i've been fine, thank you.

tied - связанный

worry about coming to class

I felt my body needed much rest.

I was rolling all night - Я ворочкался и не мог застуть)

I was sick

texture

Every musician should rehearcal in order to improve their skills.

Each musician tend to have impromptu shows.

tend 

I was opportune -  I was lucky

Когда кашляют - нужно сказать sorry ?

Be fine

Be healthy





**Jennifar notes**

Typo -> Glad..Grad



If I learn English language I can be fluent in communication

French Language

I learn English language -> ~~I learn English~~





I would be happy if somebody gave  gifts

I would be happy if somebody gifted me

My mother ‘d be happy if I call her more often.

Buy

If I found a lot of, I might buy a brown new car

I’d…Exclamation mark

 

![Описание: Image result for punctuation marks](file:///C:\Users\0249~1\AppData\Local\Temp\OICE_629436F1-8406-4D38-AE3C-CD7690A5AFDE.0\msohtmlclip1\01\clip_image002.jpg)

Comma…Continuation mark

Question mark

Quotation mark

Colon

Apostrophe

Period mark..Full stop

Exclamation point.

Hyphen

Semicolon

Bracket

 

If you were in my position, what would you do?

If you were in my shoes, what would you do?

If you had same problem, what would you do?

I would have tasted

It would taste better

If I were you, I wouldn’t wait.

What would you do if you were me?

If there weren’t … or if there wasn’t





## 11/11/18 - If I do ... and If I did - 38 (p. 87)

Make 5 sentences with ofter and 5 sentences (imagination)

1. If i do my homework Jennifer will be grad :)

2. If i didn't do my homework Jennifer would be sad :)

3. if i learn English i can speak well by English.

4. If I learned Franch I wouldn't know English.

5. I will go to training if i fill good myself tomorrow.

6. I wouldn't go to training if i caught cold.

7. I would be happy if somebody gave me gift.

8. My mother will be happy if i call often to her.

9. if i found a lot of money, i might but a new car.

10. if i save part of my salary every month i will buy new car.



## 08/11/18 - Each and every (p.193)

Find 5 new words and make 2 sentences for each of them, use 'each' and 'every'.

**New words:**

1. thief - вор (a gentleman on the highway?)
2. vital - важный
3. cloth - ткань
4. rehearsal - репетиция
5. impromptu - импровизация

**Sentences:**

1. Each thief has own tricks.
2. Every thieves break the law.
3. Each organ has vital function.
4. Every organs have difficult structure.
5. The cloths are beautiful. Each one has own structure.
6. Mom wanted to buy every one of them.
7. Each rehearsal is important because concert is soon.
8. Every rehearsal improved own skills.
9. Musicians played impromptu each. ?(like - These oranges cost 40 pence each)
10. Every one instruments sounded well.



## 22.10.18

Either - ивэ

Neither - нивэ

**89.1**

1. Do you want tea of coffee? Either. I really don't mind.

2. What day is it today - the 18th or the 19th? **Neither**. It's the 20th.

3. Where did you go on your trip - Korea or Japan?

   We went to **both**. A week in Korea and a week in Japan.

4. Shall we sit in the corner or by the window? **Either**. I don't mind.

5. Where's Lisa? Is she at work or at home? **Neither**. She's away on holiday.

**89.2**

1. Both my parents are from London.
2. both way
3. both times
4. Neither of Tom's parents
5. Neither driver ... both cars
6. both of my sister

**89.3**

1. neither of them.
2. both of them.
3. neither of us can play
4. neither of them had it.

**89.4**

1. Both Joe and Sam are on holiday.
2. Neither Joe nor Sam don't have a car.
3. Brain neither watches TV nor reads newspapers.
4. The movie are both boring and long.
5. That man't name is either Richard or Robert.
6. I have neither time nor money to go on holiday.
7. We can leave either today or tomorrow.

**89.5**

1. neither of them
2. none of them
3. neither of them
4. any time during the evening.
5. Would either of those
6. neither of us



## 17.10.18

**12.1**

1. It’s been raining **since** lunchtime.

2. Sarah has lived in Paris **since** 1995.

3. Paul has lived in Brazil **for** ten years.

4. I’m tired of waiting. We’ve been sitting here **for** an hour.

5. Kevin has been looking for a job **since** he left school.

6. I haven’t been to a party **for** ages.

7. I wonder where Joe is. I haven’t seen him **since** last week.

8. Jane is away. She’s been away **since** Friday.

9. The weather is dry. It hasn’t rained **for** a few weeks.

**12.2**

1. It’s raining.
   - How long has it been raining?
   - When did it start raining?

2. Kate is learning Japanese.
   - How long has Kate been learning Japanese?
   - When did Kate start to learn Japanese?

3. I know Simon.
   - How long have you known Simon?
   - When did you first meet Simon?

4. Rebecca and David are married.
   - How long have they been married?
   - When did they get married?

 

**2 sentences how long**

1. **How long** have you been working **today**? (Сan we use today with present prefect?)

2. **How long** has it been going this video?

**2 sentences when**

1. **When** did you start to work today?

2. **When** did this video start?

**2 sentences since**

1. I haven’t seen him **since** he visited us in last year.

2. He hasn’t played in computer games **since** 2010.
   - He hasn’t been playing in computer games **since** 2010.
   - He has been playing in computer games **since** 2010.

**2 sentences for**

1. I haven’t seen him **for** ages.

2. He’s been watching a serial **for** six hours.

 

## Lesson

Send

Sent

Sending

I’ve sent the money into your account

Online banking

I transferred the money into your account.

How long have been learning English?

I started learning English when I was in High school but unfortunately I wasn’t taught very well and there were lesser practice to improve my communication skills.

You know more than what you knew before

Go ahead

 

Can you see my screen?

Yes, I can!

Yes, I can see.

I have been learning English for a long time 

I have been learning 

I have been an engineer for 3 years

I have been working as an engineer for 3years

Could you please work on my laptop?

Yes I can!

How long is it going to take to work on it?

It’s going to take me 3hours.

Are you working on it?

No, I’m not yet done.

A friend of yours

I have been working on it for 6 hours

I have been working on the laptop since yesterday

Did Jennifer go to school today?

lt's ages since we went to the cinema. or lt's been ages since .. .  It has been  It’s

 

When and How long

How long goes with been

How long +been + present continuous

How long have you been studying Russian Language?

I have been studying Russian language since 2017

A year… 2 years

How long have you been living in Paris?

I have been living in Paris since I was a child

I have in Paris for 5 years.

 

How long have you been in Paris?

I have been in Paris for 2 weeks

I have been Paris since last week Monday 

 

 

Live……Go

Live…..Public see (internet)

Lives… Plural “Our lives

Life… Singular “my life

Leave… go “leaving.. going”

Leaves….. plural

Leaf..Singular

Living  ///  Reside…Continuous

Jennifer where do you reside?

 

When?

When did you live for Paris

I left last week

I left for Paris two days ago

When was the last time you visit St.P

I visited the city 2 months ago

When was the last you went to Jennifer’s house?

The last I visited Jennifer was when I was a child

Since I left the city, I haven’t been able to visit Jennifer.

 

Sunday