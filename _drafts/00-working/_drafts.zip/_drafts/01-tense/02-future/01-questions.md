# [Test](https://docs.google.com/forms/d/e/1FAIpQLSdkQLfZaWmHpFbYLT2lt8DNyNzzSwi_p9_l3sZWYm185YHhnw/viewform)

1. My grandparents are *going to retire* / *will retire* next year. (**Both**)
2. ~~Will we~~ / **Shall we** invite your parents for Sunday lunch?
3. *I'm going to make* / *I'll make* a cake for your mum's birthday, if you want. (**Both**)
4. *I'm not having* / *I'm not going to have* dinner with my family tonight. (**Both**)
5. The exam **will be** / ~~is being~~ on the last Friday of term. (not future arrangements, be is state)
6. You can trust me. ~~I'm not telling~~ / **I won't tell** anyone what you told me.
7. My cousin **is arriving** / ~~will arrive~~ at 5.30 p.m. down in my county in the next few years.
8. I think the birth rate **will go down** / ~~shall go down~~ in my country in the next few years.
9. **I'm not going to go** / ~~I won't go~~ to my brother-in-law's party next weekend.
10. **Shall I** / ~~Will I~~ help you with the washing-up?